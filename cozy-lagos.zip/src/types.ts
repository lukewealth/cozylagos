/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Listing {
  id: string;
  title: string;
  description: string;
  category: "Penthouse" | "Luxury Villa" | "Executive Studio" | "Serviced Apartment";
  location: "Ikoyi" | "Victoria Island" | "Banana Island" | "Lekki Phase 1";
  bedrooms: number;
  bathrooms: number;
  maxGuests: number;
  nightlyRate: number;
  weekendPremium: number; // percentage, e.g. 15
  cleaningFee: number;
  securityDeposit: number;
  image: string;
  images: string[];
  amenities: string[];
  ownerId: string;
  isActive: boolean;
  reviewsCount: number;
  rating: number;
  aiMatchPercent: number;
}

export interface Booking {
  id: string;
  listingId: string;
  listingTitle: string;
  guestName: string;
  guestEmail: string;
  guestAvatar?: string;
  checkIn: string;
  checkOut: string;
  guestsCount: number;
  status: "Pending" | "Confirmed" | "Completed" | "Cancelled";
  totalAmount: number;
  chefAdded?: boolean;
  photographerAdded?: boolean;
  jetskiAdded?: boolean;
}

export interface Transaction {
  id: string;
  date: string;
  reference: string;
  type: "Payout" | "Booking Revenue" | "Refund" | "Redemption";
  amount: number;
  status: "Pending" | "Processed";
  description: string;
}

export interface ChatMessage {
  id: string;
  sender: "user" | "concierge" | "host";
  text: string;
  timestamp: string;
}
