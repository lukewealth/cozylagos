import React from 'react';
import { Compass, User, Bell, ChevronRight, RefreshCw, ShieldCheck } from 'lucide-react';

interface TopNavBarProps {
  portal: 'guest' | 'owner';
  setPortal: (portal: 'guest' | 'owner') => void;
  activeTab: string;
  setActiveTab: (tab: any) => void;
}

export default function TopNavBar({ portal, setPortal, activeTab, setActiveTab }: TopNavBarProps) {
  return (
    <header className="sticky top-0 z-50 w-full bg-parchment/85 backdrop-blur-xl border-b border-charcoal/5 shadow-sm">
      <div className="flex justify-between items-center w-full px-6 md:px-12 xl:px-20 max-w-[1440px] mx-auto h-20">
        
        {/* Logo and Brand */}
        <div className="flex items-center gap-4">
          <div 
            onClick={() => {
              if (portal === 'guest') {
                setActiveTab('home');
              } else {
                setActiveTab('overview');
              }
            }}
            className="font-serif italic text-2xl font-bold tracking-tight text-gold-dark cursor-pointer select-none hover:opacity-85 transition-opacity"
          >
            Cozy Lagos
          </div>
          
          {/* Elite Host badge */}
          <div className="hidden sm:flex items-center gap-1.5 bg-gold/10 border border-gold/20 px-2.5 py-0.5 rounded-full text-[10px] text-gold-dark font-semibold tracking-wider uppercase">
            <ShieldCheck className="w-3 h-3" />
            <span>Lagos Elite Certified</span>
          </div>
        </div>

        {/* Center Links (Based on active Portal) */}
        <nav className="hidden md:flex items-center gap-8 text-[11px] font-bold tracking-[0.15em] uppercase">
          {portal === 'guest' ? (
            <>
              <button 
                onClick={() => setActiveTab('home')}
                className={`py-2 px-1 relative transition-colors ${activeTab === 'home' ? 'text-charcoal' : 'text-charcoal-light hover:text-charcoal'}`}
              >
                Home
                {activeTab === 'home' && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gold" />}
              </button>
              <button 
                onClick={() => setActiveTab('explorer')}
                className={`py-2 px-1 relative transition-colors ${activeTab === 'explorer' ? 'text-charcoal' : 'text-charcoal-light hover:text-charcoal'}`}
              >
                Stays
                {activeTab === 'explorer' && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gold" />}
              </button>
              <button 
                onClick={() => setActiveTab('experience')}
                className={`py-2 px-1 relative transition-colors ${activeTab === 'experience' ? 'text-charcoal' : 'text-charcoal-light hover:text-charcoal'}`}
              >
                Experiences
                {activeTab === 'experience' && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gold" />}
              </button>
              <button 
                onClick={() => setActiveTab('guest-dashboard')}
                className={`py-2 px-1 relative transition-colors ${activeTab === 'guest-dashboard' ? 'text-charcoal' : 'text-charcoal-light hover:text-charcoal'}`}
              >
                Concierge & Dashboard
                {activeTab === 'guest-dashboard' && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gold" />}
              </button>
            </>
          ) : (
            <>
              <button 
                onClick={() => setActiveTab('overview')}
                className={`py-2 px-1 relative transition-colors ${activeTab === 'overview' ? 'text-charcoal' : 'text-charcoal-light hover:text-charcoal'}`}
              >
                Performance Overview
                {activeTab === 'overview' && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gold" />}
              </button>
              <button 
                onClick={() => setActiveTab('listings')}
                className={`py-2 px-1 relative transition-colors ${activeTab === 'listings' ? 'text-charcoal' : 'text-charcoal-light hover:text-charcoal'}`}
              >
                My Listings
                {activeTab === 'listings' && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gold" />}
              </button>
              <button 
                onClick={() => setActiveTab('calendar')}
                className={`py-2 px-1 relative transition-colors ${activeTab === 'calendar' ? 'text-charcoal' : 'text-charcoal-light hover:text-charcoal'}`}
              >
                Availability Calendar
                {activeTab === 'calendar' && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gold" />}
              </button>
              <button 
                onClick={() => setActiveTab('payouts')}
                className={`py-2 px-1 relative transition-colors ${activeTab === 'payouts' ? 'text-charcoal' : 'text-charcoal-light hover:text-charcoal'}`}
              >
                Payout Ledger
                {activeTab === 'payouts' && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gold" />}
              </button>
            </>
          )}
        </nav>

        {/* Right Side Portal Switcher and Actions */}
        <div className="flex items-center gap-4">
          
          {/* Quick toggle mode portal button */}
          <button
            onClick={() => {
              const newPortal = portal === 'guest' ? 'owner' : 'guest';
              setPortal(newPortal);
              setActiveTab(newPortal === 'guest' ? 'home' : 'overview');
            }}
            className="flex items-center gap-2 px-3 py-1.5 bg-charcoal text-parchment hover:bg-gold-dark hover:text-parchment rounded-full text-[10px] font-bold tracking-wider uppercase transition-colors shrink-0"
            title={portal === 'guest' ? "Switch to Host View" : "Switch to Guest View"}
          >
            <RefreshCw className="w-3 h-3" />
            <span className="hidden sm:inline">Swap to {portal === 'guest' ? 'Host View' : 'Guest View'}</span>
            <span className="sm:hidden">{portal === 'guest' ? 'Host' : 'Guest'}</span>
          </button>

          {/* User Icon */}
          <button 
            type="button"
            className="hidden sm:flex items-center justify-center w-9 h-9 rounded-full bg-charcoal/5 hover:bg-gold/15 hover:text-gold-dark transition-colors"
          >
            <Bell className="w-4 h-4 text-charcoal/70" />
          </button>
          
          <button 
            type="button"
            onClick={() => {
              if (portal === 'guest') {
                setActiveTab('guest-dashboard');
              } else {
                setActiveTab('overview');
              }
            }}
            className="flex items-center gap-2 border border-charcoal/50 px-4 py-2 hover:bg-charcoal hover:text-parchment rounded-full text-[10px] font-bold tracking-wider uppercase transition-all duration-300"
          >
            <User className="w-3.5 h-3.5" />
            <span>Profile</span>
          </button>
        </div>
      </div>
    </header>
  );
}
